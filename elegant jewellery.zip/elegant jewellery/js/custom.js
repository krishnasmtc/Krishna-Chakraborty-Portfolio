// menu
function toggleMenu() {
  const nav = document.getElementById("navMenu");
  const overlay = document.getElementById("overlay");
  const icon = document.getElementById("menuIcon");

  nav.classList.toggle("active");
  overlay.classList.toggle("active");

  // Toggle icon between hamburger and nothing (mobile nav has its own close)
  if (nav.classList.contains("active")) {
    icon.classList.remove("fa-bars");
    icon.classList.add("fa-times");
  } else {
    icon.classList.remove("fa-times");
    icon.classList.add("fa-bars");
  }
}

//
// hero slider
var swiperq = new Swiper(".mySwiper", {
  spaceBetween: 30,
  effect: "fade",
  autoplay: {
    delay: 2500,
    disableOnInteraction: false,
  },
});
//
// info
var swiper_info = new Swiper(".mySwiperinfo", {
  slidesPerView: 2,
  spaceBetween: 20,
  autoplay: {
    delay: 2500,
    disableOnInteraction: false,
  },
  breakpoints: {
    640: {
      slidesPerView: 2,
      spaceBetween: 20,
    },
    768: {
      slidesPerView: 4,
      spaceBetween: 10,
    },
    1024: {
      slidesPerView: 7,
      spaceBetween: 20,
    },
  },
});
